// MySQL API Configuration
const API_BASE_URL = '../api/music.php';
const AUTH_API = '../api/auth.php';
let currentPlaylist = [];
let currentTrackIndex = 0;
let isShuffling = false;
let isRepeating = false;
let currentUser = null;

// Authentication & Profile Functions
async function checkAuthentication() {
    try {
        const response = await fetch(`${AUTH_API}?action=check`);
        const data = await response.json();

        if (data.authenticated) {
            currentUser = data.user;
            updateProfileUI();
            setupProfileButton();
        } else {
            // Redirect to login if not authenticated
            window.location.href = 'login.html';
        }
    } catch (error) {
        console.error('Auth check error:', error);
        window.location.href = 'login.html';
    }
}

function updateProfileUI() {
    if (!currentUser) return;

    const initials = ((currentUser.firstName || '')[0] + (currentUser.lastName || '')[0]).toUpperCase() || currentUser.username[0].toUpperCase();
    
    // Update profile button avatar
    const profileAvatarMini = document.getElementById('profileAvatarMini');
    if (profileAvatarMini) {
        profileAvatarMini.textContent = initials;
    }

    // Update profile dropdown
    const profileDropdownAvatar = document.getElementById('profileDropdownAvatar');
    const profileDropdownName = document.getElementById('profileDropdownName');
    const profileDropdownUsername = document.getElementById('profileDropdownUsername');

    if (profileDropdownAvatar) profileDropdownAvatar.textContent = initials;
    if (profileDropdownName) profileDropdownName.textContent = `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim() || currentUser.username;
    if (profileDropdownUsername) profileDropdownUsername.textContent = `@${currentUser.username}`;
}

function setupProfileButton() {
    const profileButton = document.getElementById('profileButton');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileButton) {
        profileButton.addEventListener('click', toggleProfileMenu);
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (profileDropdown && profileButton && 
            !profileDropdown.contains(event.target) && 
            !profileButton.contains(event.target)) {
            profileDropdown.classList.remove('active');
        }
    });
}

function toggleProfileMenu() {
    const profileDropdown = document.getElementById('profileDropdown');
    if (profileDropdown) {
        profileDropdown.classList.toggle('active');
    }
}

async function handleLogout(event) {
    event.preventDefault();
    
    // Show SweetAlert2 confirmation dialog
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out from TuneLocal',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#1db954',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, logout',
        cancelButtonText: 'Cancel',
        background: '#282828',
        color: '#ffffff',
        customClass: {
            popup: 'swal-dark-bg',
            title: 'swal-dark-title',
            content: 'swal-dark-content'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Proceed with logout
            performLogout();
        }
    });
}

async function performLogout() {
    try {
        await fetch(`${AUTH_API}?action=logout`, { method: 'POST' });
        
        // Show success message before redirecting
        Swal.fire({
            title: 'Logged Out',
            text: 'You have been successfully logged out',
            icon: 'success',
            confirmButtonColor: '#1db954',
            background: '#282828',
            color: '#ffffff',
            timer: 1500,
            timerProgressBar: true
        }).then(() => {
            window.location.href = './landing.html';
        });
    } catch (error) {
        console.error('Logout error:', error);
        
        // Show error message
        Swal.fire({
            title: 'Error',
            text: 'Failed to logout. Redirecting...',
            icon: 'error',
            confirmButtonColor: '#1db954',
            background: '#282828',
            color: '#ffffff',
            timer: 1500,
            timerProgressBar: true
        }).then(() => {
            window.location.href = './landing.html';
        });
    }
}

// Navigation & Section Management
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication first
    checkAuthentication();

    // Initialize
    loadSavedPlaylists();
    loadSavedSongs();
    setupEventListeners();
    setupOfflineMusicListeners();
    loadOfflineMusicFromMySQL();
    initializeDiscover();
    // Apply saved theme
    try {
        const savedTheme = preferencesManager?.get('theme', 'dark');
        applyTheme(savedTheme);
    } catch {}

    // Setup theme toggle
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.setAttribute('role', 'button');
        themeToggle.setAttribute('aria-label', 'Toggle theme');
        themeToggle.setAttribute('tabindex', '0');
        themeToggle.style.cursor = 'pointer';
        
        themeToggle.addEventListener('click', function() {
            const nextTheme = document.body.classList.contains('light-theme') ? 'dark' : 'light';
            applyTheme(nextTheme);
        });
        
        themeToggle.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const nextTheme = document.body.classList.contains('light-theme') ? 'dark' : 'light';
                applyTheme(nextTheme);
            }
        });
    }
    
    // Smooth scroll for navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId);
            
            // Update active nav link
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
});

// Show specific section
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-section') === sectionId) {
            link.classList.add('active');
        }
    });
}

function applyTheme(theme) {
    const isLight = theme === 'light';
    document.body.classList.toggle('light-theme', isLight);
    const icon = themeToggle.querySelector('i');
    if (isLight) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
        themeToggle.setAttribute('aria-pressed', 'true');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
        themeToggle.setAttribute('aria-pressed', 'false');
    }
    try { preferencesManager?.set('theme', isLight ? 'light' : 'dark'); } catch {}
}

// Spotify Functions
function loadSpotify() {
    const url = document.getElementById('spotifyUrl').value.trim();
    const playerDiv = document.getElementById('spotifyPlayer');
    
    if (!url) {
        showNotification('Please enter a Spotify URL', 'error');
        return;
    }
    
    const embedUrl = convertToSpotifyEmbed(url);
    
    if (embedUrl) {
        playerDiv.innerHTML = `
            <iframe 
                style="border-radius:12px" 
                src="${embedUrl}" 
                width="100%" 
                height="400" 
                frameBorder="0" 
                allowfullscreen="" 
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
                loading="lazy">
            </iframe>
        `;
        
        // Save to saved songs
        saveSongToHistory(url, 'spotify');
        
        showNotification('Spotify content loaded successfully!', 'success');
    } else {
        showNotification('Invalid Spotify URL. Please check and try again.', 'error');
    }
}

function convertToSpotifyEmbed(url) {
    // Extract Spotify ID from various URL formats
    let match;
    
    // Standard Spotify URL: https://open.spotify.com/playlist/ID
    match = url.match(/spotify\.com\/(playlist|album|track|artist)\/([a-zA-Z0-9]+)/);
    if (match) {
        return `https://open.spotify.com/embed/${match[1]}/${match[2]}?utm_source=generator`;
    }
    
    // Spotify URI: spotify:playlist:ID
    match = url.match(/spotify:(playlist|album|track|artist):([a-zA-Z0-9]+)/);
    if (match) {
        return `https://open.spotify.com/embed/${match[1]}/${match[2]}?utm_source=generator`;
    }
    
    return null;
}

function loadPresetSpotify(path) {
    const playerDiv = document.getElementById('spotifyPlayer');
    const embedUrl = `https://open.spotify.com/embed/${path}?utm_source=generator`;
    
    playerDiv.innerHTML = `
        <iframe 
            style="border-radius:12px" 
            src="${embedUrl}" 
            width="100%" 
            height="400" 
            frameBorder="0" 
            allowfullscreen="" 
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
            loading="lazy">
        </iframe>
    `;
    
    // Switch to Spotify section
    showSection('spotify');
    showNotification('Preset playlist loaded!', 'success');
}

// YouTube Functions
function loadYouTube() {
    const url = document.getElementById('youtubeUrl').value.trim();
    const playerDiv = document.getElementById('youtubePlayer');
    
    if (!url) {
        showNotification('Please enter a YouTube URL', 'error');
        return;
    }
    
    const embedUrl = convertToYouTubeEmbed(url);
    
    if (embedUrl) {
        playerDiv.innerHTML = `
            <iframe 
                width="100%" 
                height="500" 
                src="${embedUrl}" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen
                style="border-radius: 16px;">
            </iframe>
        `;
        
        // Save to saved songs
        saveSongToHistory(url, 'youtube');
        
        showNotification('YouTube video loaded successfully!', 'success');
    } else {
        showNotification('Invalid YouTube URL. Please check and try again.', 'error');
    }
}

function convertToYouTubeEmbed(url) {
    let videoId = null;
    let playlistId = null;
    
    // Extract video ID
    const videoMatch = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    if (videoMatch) {
        videoId = videoMatch[1];
    }
    
    // Extract playlist ID
    const playlistMatch = url.match(/[?&]list=([^&]+)/);
    if (playlistMatch) {
        playlistId = playlistMatch[1];
    }
    
    // Build embed URL
    if (videoId) {
        let embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
        if (playlistId) {
            embedUrl += `&list=${playlistId}`;
        }
        return embedUrl;
    } else if (playlistId) {
        return `https://www.youtube.com/embed/videoseries?list=${playlistId}&autoplay=1`;
    }
    
    return null;
}

function loadPresetYouTube(url) {
    const embedUrl = convertToYouTubeEmbed(url);
    const playerDiv = document.getElementById('youtubePlayer');
    
    if (embedUrl) {
        playerDiv.innerHTML = `
            <iframe 
                width="100%" 
                height="500" 
                src="${embedUrl}" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen
                style="border-radius: 16px;">
            </iframe>
        `;
        
        // Switch to YouTube section
        showSection('youtube');
        showNotification('Preset video loaded!', 'success');
    }
}

// Playlist Management
function togglePlaylistForm() {
    const form = document.getElementById('playlistForm');
    if (form.style.display === 'none' || form.style.display === '') {
        form.style.display = 'block';
        form.style.animation = 'fadeIn 0.3s ease-in-out';
    } else {
        form.style.display = 'none';
    }
}

function savePlaylist() {
    const name = document.getElementById('playlistName').value.trim();
    const url = document.getElementById('playlistUrl').value.trim();
    const type = document.getElementById('playlistType').value;
    
    if (!name || !url) {
        showNotification('Please fill in all fields', 'error');
        return;
    }
    
    // Get existing playlists
    let playlists = JSON.parse(localStorage.getItem('tunelocal_playlists') || '[]');
    
    // Add new playlist
    const playlist = {
        id: Date.now(),
        name: name,
        url: url,
        type: type,
        dateAdded: new Date().toLocaleDateString()
    };
    
    playlists.push(playlist);
    localStorage.setItem('tunelocal_playlists', JSON.stringify(playlists));
    
    // Clear form
    document.getElementById('playlistName').value = '';
    document.getElementById('playlistUrl').value = '';
    togglePlaylistForm();
    
    // Reload playlists
    loadSavedPlaylists();
    showNotification('Playlist saved successfully!', 'success');
}

function loadSavedPlaylists() {
    const playlists = JSON.parse(localStorage.getItem('tunelocal_playlists') || '[]');
    const container = document.getElementById('savedPlaylists');
    
    if (playlists.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                <i class="fas fa-music" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                <p>No saved playlists yet. Add your first playlist above!</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = playlists.map(playlist => `
        <div class="playlist-item" data-id="${playlist.id}">
            <div class="playlist-info">
                <i class="fab fa-${playlist.type}"></i>
                <div class="playlist-details">
                    <h4>${playlist.name}</h4>
                    <p>Added on ${playlist.dateAdded}</p>
                </div>
            </div>
            <div class="playlist-actions">
                <button class="icon-btn" onclick="playPlaylist('${playlist.url}', '${playlist.type}')" title="Play">
                    <i class="fas fa-play"></i>
                </button>
                <button class="icon-btn delete" onclick="deletePlaylist(${playlist.id})" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function playPlaylist(url, type) {
    if (type === 'spotify') {
        document.getElementById('spotifyUrl').value = url;
        loadSpotify();
        showSection('spotify');
    } else if (type === 'youtube') {
        document.getElementById('youtubeUrl').value = url;
        loadYouTube();
        showSection('youtube');
    }
}

function deletePlaylist(id) {
    if (!confirm('Are you sure you want to delete this playlist?')) {
        return;
    }
    
    let playlists = JSON.parse(localStorage.getItem('tunelocal_playlists') || '[]');
    playlists = playlists.filter(p => p.id !== id);
    localStorage.setItem('tunelocal_playlists', JSON.stringify(playlists));
    
    loadSavedPlaylists();
    showNotification('Playlist deleted', 'success');
}

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notification
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#1db954' : type === 'error' ? '#ff0050' : '#667eea'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        animation: slideIn 0.3s ease-out;
        font-weight: 500;
    `;
    
    document.body.appendChild(notification);
    // Update ARIA live region for assistive tech
    const ariaLive = document.getElementById('ariaLive');
    if (ariaLive) {
        ariaLive.textContent = message;
    }
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add notification animations to CSS dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Setup Event Listeners
function setupEventListeners() {
    // Enter key support for URL inputs
    document.getElementById('spotifyUrl').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loadSpotify();
        }
    });
    
    document.getElementById('youtubeUrl').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loadYouTube();
        }
    });
    
    document.getElementById('downloadUrl').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchForDownload();
        }
    });
    
    // Form input validation
    const inputs = document.querySelectorAll('.form-input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.style.borderColor = 'var(--primary-color)';
        });
        
        input.addEventListener('blur', function() {
            this.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        });
    });
}

// Offline Music Functions
function setupOfflineMusicListeners() {
    const fileInput = document.getElementById('fileInput');
    const uploadArea = document.getElementById('uploadArea');
    const audioPlayer = document.getElementById('audioPlayer');
    
    // File input change
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag and drop
    uploadArea.addEventListener('click', () => fileInput.click());
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        const files = e.dataTransfer.files;
        handleFiles(files);
    });
    
    // Audio player events
    audioPlayer.addEventListener('ended', () => {
        if (isRepeating) {
            audioPlayer.currentTime = 0;
            audioPlayer.play();
        } else {
            nextTrack();
        }
    });
    
    audioPlayer.addEventListener('play', () => {
        document.getElementById('playIcon').className = 'fas fa-pause';
    });
    
    audioPlayer.addEventListener('pause', () => {
        document.getElementById('playIcon').className = 'fas fa-play';
    });
}

function handleFileSelect(e) {
    handleFiles(e.target.files);
}

function handleFiles(files) {
    if (files.length === 0) return;
    
    let uploadCount = 0;
    let errorCount = 0;
    
    Array.from(files).forEach(file => {
        // Accept both audio and video files (MP4, WEBM, etc.)
        if (file.type.startsWith('audio/') || file.type.startsWith('video/')) {
            saveOfflineMusic(file);
            uploadCount++;
        } else if (file.name.match(/\.(mp3|mp4|wav|ogg|m4a|webm|flac|aac)$/i)) {
            // Fallback: check file extension if MIME type is not detected
            saveOfflineMusic(file);
            uploadCount++;
        } else {
            showNotification(`${file.name} is not a supported audio/video file`, 'error');
            errorCount++;
        }
    });
    
    if (uploadCount > 0) {
        showNotification(`Uploading ${uploadCount} file(s)...`, 'success');
    }
}

function saveOfflineMusic(file) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const formData = new FormData();
        formData.append('action', 'upload');
        formData.append('name', file.name.replace(/\.[^/.]+$/, ''));
        formData.append('fileName', file.name);
        formData.append('fileType', file.type);
        formData.append('fileSize', file.size);
        formData.append('fileData', e.target.result);
        
        fetch(API_BASE_URL, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            // Check if response is ok
            if (!response.ok) {
                return response.text().then(text => {
                    throw new Error(`Server error: ${text}`);
                });
            }
            return response.text().then(text => {
                try {
                    return JSON.parse(text);
                } catch (e) {
                    console.error('Invalid JSON response:', text);
                    throw new Error('Server returned invalid JSON. Check console for details.');
                }
            });
        })
        .then(data => {
            if (data.success) {
                showNotification(`${file.name} uploaded successfully!`, 'success');
                loadOfflineMusicFromMySQL();
            } else {
                showNotification(`Failed to upload ${file.name}: ${data.error}`, 'error');
            }
        })
        .catch(error => {
            console.error('Upload error:', error);
            showNotification(`Upload error: ${error.message}`, 'error');
        });
    };
    
    reader.readAsDataURL(file);
}

function loadOfflineMusicFromMySQL() {
    fetch(API_BASE_URL + '?action=list')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentPlaylist = data.tracks;
                updateAllTracksCache(data.tracks);
                displayOfflineMusicFromMySQL(data.tracks);
                updateStorageStatsMySQL();

                // Sync enhanced offline player (if present) with MySQL-backed library
                if (typeof enhancedOfflinePlayer !== 'undefined' &&
                    enhancedOfflinePlayer &&
                    typeof enhancedOfflinePlayer.syncFromMySQL === 'function') {
                    enhancedOfflinePlayer.syncFromMySQL(data.tracks);
                }
            } else {
                showNotification('Failed to load music library', 'error');
            }
        })
        .catch(error => {
            showNotification('Error loading music: ' + error.message, 'error');
        });
}

function updateStorageStatsMySQL() {
    fetch(API_BASE_URL + '?action=stats')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.stats) {
                const stats = data.stats;
                document.getElementById('storageUsed').textContent = formatFileSize(parseInt(stats.total_size) || 0);
                document.getElementById('totalFiles').textContent = stats.total_tracks || 0;
                document.getElementById('storageAvailable').textContent = 'Unlimited (MySQL)';
            }
        })
        .catch(error => {
            console.error('Error loading stats:', error);
        });
}

function displayOfflineMusicFromMySQL(tracks) {
    const container = document.getElementById('musicTracks');
    const trackCount = document.getElementById('trackCount');
    
    trackCount.textContent = tracks.length;
    
    if (tracks.length === 0) {
        container.innerHTML = `
            <div class="empty-library">
                <i class="fas fa-music"></i>
                <h3>Your Library is Empty</h3>
                <p>Upload your music files to start listening offline!</p>
                <p style="margin-top: 1rem; color: var(--primary-color);">
                    <i class="fas fa-database"></i> Powered by MySQL - Unlimited Storage!
                </p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = tracks.map((track, index) => {
        // Determine icon based on file type
        const isVideo = track.file_type.startsWith('video/') || track.file_name.match(/\.(mp4|webm|mov|avi)$/i);
        const icon = isVideo ? 'fa-video' : 'fa-music';
        
        return `
        <div class="track-item" onclick="playOfflineTrackMySQL(${track.id}, ${index})">
            <div class="track-number">${index + 1}</div>
            <i class="fas ${icon} track-icon"></i>
            <div class="track-details">
                <div class="track-name">${track.name}</div>
                <div class="track-meta">
                    ${formatFileSize(parseInt(track.file_size))} • ${new Date(track.date_added).toLocaleDateString()}
                    ${track.play_count > 0 ? `• Played ${track.play_count} times` : ''}
                </div>
            </div>
            <div class="track-actions">
                <button class="icon-btn" onclick="event.stopPropagation(); exportTrackMySQL(${track.id})" title="Export/Download">
                    <i class="fas fa-download"></i>
                </button>
                <button class="icon-btn delete" onclick="event.stopPropagation(); deleteOfflineTrackMySQL(${track.id})" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        `;
    }).join('');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Store all tracks for searching
let allOfflineTracks = [];

function updateAllTracksCache(tracks) {
    allOfflineTracks = tracks;
}

function searchOfflineMusic(query) {
    const searchTerm = query.toLowerCase().trim();
    
    if (!searchTerm) {
        displayOfflineMusicFromMySQL(allOfflineTracks);
        return;
    }
    
    const filtered = allOfflineTracks.filter(track => 
        track.name.toLowerCase().includes(searchTerm) ||
        track.file_name.toLowerCase().includes(searchTerm)
    );
    
    displayOfflineMusicFromMySQL(filtered);
}

function playOfflineTrackMySQL(id, index) {
    fetch(API_BASE_URL + '?action=get&id=' + id)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.track) {
                const track = data.track;
                const audioPlayer = document.getElementById('audioPlayer');
                const nowPlayingSection = document.getElementById('nowPlayingSection');
                
                audioPlayer.src = track.file_data;
                audioPlayer.play();
                
                currentTrackIndex = index;
                
                // Update UI
                document.getElementById('currentTrackName').textContent = track.name;
                document.getElementById('currentTrackArtist').textContent = track.file_name;
                nowPlayingSection.style.display = 'block';
                
                // Update playing state
                document.querySelectorAll('.track-item').forEach((item, i) => {
                    if (i === index) {
                        item.classList.add('playing');
                    } else {
                        item.classList.remove('playing');
                    }
                });
                
                showNotification(`Now playing: ${track.name}`, 'success');
            } else {
                showNotification('Failed to load track', 'error');
            }
        })
        .catch(error => {
            showNotification('Error playing track: ' + error.message, 'error');
        });
}

function togglePlay() {
    const audioPlayer = document.getElementById('audioPlayer');
    if (audioPlayer.paused) {
        audioPlayer.play();
    } else {
        audioPlayer.pause();
    }
}

function nextTrack() {
    if (currentPlaylist.length === 0) return;
    
    if (isShuffling) {
        currentTrackIndex = Math.floor(Math.random() * currentPlaylist.length);
    } else {
        currentTrackIndex = (currentTrackIndex + 1) % currentPlaylist.length;
    }
    
    playOfflineTrackMySQL(currentPlaylist[currentTrackIndex].id, currentTrackIndex);
}

function previousTrack() {
    if (currentPlaylist.length === 0) return;
    
    currentTrackIndex = (currentTrackIndex - 1 + currentPlaylist.length) % currentPlaylist.length;
    playOfflineTrackMySQL(currentPlaylist[currentTrackIndex].id, currentTrackIndex);
}

function toggleShuffle() {
    isShuffling = !isShuffling;
    const btn = document.getElementById('shuffleBtn');
    
    if (isShuffling) {
        btn.classList.add('active');
        showNotification('Shuffle enabled', 'success');
    } else {
        btn.classList.remove('active');
        showNotification('Shuffle disabled', 'success');
    }
}

function toggleRepeat() {
    isRepeating = !isRepeating;
    const btn = document.getElementById('repeatBtn');
    
    if (isRepeating) {
        btn.classList.add('active');
        showNotification('Repeat enabled', 'success');
    } else {
        btn.classList.remove('active');
        showNotification('Repeat disabled', 'success');
    }
}

function deleteOfflineTrackMySQL(id) {
    if (!confirm('Delete this track from your offline library?')) {
        return;
    }
    
    fetch(API_BASE_URL + '?id=' + id, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Track deleted', 'success');
            loadOfflineMusicFromMySQL();
            
            // Stop playback if this was the current track
            const audioPlayer = document.getElementById('audioPlayer');
            if (currentPlaylist[currentTrackIndex]?.id === id) {
                audioPlayer.pause();
                audioPlayer.src = '';
                document.getElementById('currentTrackName').textContent = 'No track playing';
                document.getElementById('currentTrackArtist').textContent = 'Select a song to play';
            }
        } else {
            showNotification('Failed to delete track', 'error');
        }
    })
    .catch(error => {
        showNotification('Error deleting track: ' + error.message, 'error');
    });
}

function clearAllOfflineMusicMySQL() {
    if (!confirm('Delete ALL tracks from your offline library? This cannot be undone!')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'clear');
    
    fetch(API_BASE_URL, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('All tracks deleted', 'success');
            loadOfflineMusicFromMySQL();
            
            const audioPlayer = document.getElementById('audioPlayer');
            audioPlayer.pause();
            audioPlayer.src = '';
            document.getElementById('currentTrackName').textContent = 'No track playing';
            document.getElementById('currentTrackArtist').textContent = 'Select a song to play';
            document.getElementById('nowPlayingSection').style.display = 'none';
        } else {
            showNotification('Failed to clear library', 'error');
        }
    })
    .catch(error => {
        showNotification('Error: ' + error.message, 'error');
    });
}

function clearAllOfflineMusic() {
    clearAllOfflineMusicMySQL();
}

// Export Functions
function exportTrackMySQL(id) {
    fetch(API_BASE_URL + '?action=get&id=' + id)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.track) {
                const track = data.track;
                downloadFile(track.file_data, track.file_name, track.file_type);
                showNotification(`Exporting ${track.name}...`, 'success');
            } else {
                showNotification('Failed to export track', 'error');
            }
        })
        .catch(error => {
            showNotification('Error exporting track: ' + error.message, 'error');
        });
}

function exportAllMusic() {
    if (currentPlaylist.length === 0) {
        showNotification('No tracks to export', 'error');
        return;
    }
    
    if (!confirm(`Export all ${currentPlaylist.length} tracks? They will be downloaded to your Downloads folder.`)) {
        return;
    }
    
    showNotification(`Exporting ${currentPlaylist.length} files...`, 'success');
    
    currentPlaylist.forEach((track, index) => {
        setTimeout(() => {
            exportTrackMySQL(track.id);
        }, index * 500); // Delay each download by 500ms to avoid browser blocking
    });
    
    setTimeout(() => {
        showNotification('All files exported successfully!', 'success');
    }, currentPlaylist.length * 500 + 1000);
}

function downloadFile(dataUrl, fileName, mimeType) {
    // Create a temporary link element
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = fileName;
    link.style.display = 'none';
    
    // Append to body, click, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Music Downloader Functions
let currentVideoUrl = '';

function searchForDownload() {
    const url = document.getElementById('downloadUrl').value.trim();
    
    if (!url) {
        showNotification('Please enter a YouTube URL', 'error');
        return;
    }
    
    // Validate YouTube URL
    const videoId = extractYouTubeVideoId(url);
    
    if (!videoId) {
        showNotification('Invalid YouTube URL. Please check and try again.', 'error');
        return;
    }
    
    currentVideoUrl = url;
    
    // Show video info section
    const videoInfoSection = document.getElementById('videoInfoSection');
    videoInfoSection.style.display = 'block';
    
    // Set thumbnail
    const thumbnail = document.getElementById('videoThumbnail');
    thumbnail.innerHTML = `<img src="https://img.youtube.com/vi/${videoId}/maxresdefault.jpg" alt="Video Thumbnail" onerror="this.src='https://img.youtube.com/vi/${videoId}/hqdefault.jpg'">`;
    
    // Enable download buttons
    enableDownloadButtons();
    
    // Update UI
    document.getElementById('videoTitle').textContent = 'YouTube Video';
    document.getElementById('videoChannel').textContent = 'Video ID: ' + videoId;
    document.getElementById('videoDuration').textContent = 'Ready to download';
    
    showNotification('Video loaded! Choose a download service below.', 'success');
    
    // Scroll to download services
    document.querySelector('.download-services').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function extractYouTubeVideoId(url) {
    // Extract video ID from various YouTube URL formats
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/,
        /youtube\.com\/embed\/([^&\n?#]+)/,
        /youtube\.com\/v\/([^&\n?#]+)/
    ];
    
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
            return match[1];
        }
    }
    
    return null;
}

function enableDownloadButtons() {
    const buttons = [
        'ytmp3Btn', 'y2mateBtn', 'loaderBtn', 
        'savefromBtn', 'mp3juiceBtn', 'yt5sBtn'
    ];
    
    buttons.forEach(btnId => {
        const btn = document.getElementById(btnId);
        if (btn) btn.disabled = false;
    });
}

function openDownloadService(service) {
    if (!currentVideoUrl) {
        showNotification('Please search for a video first', 'error');
        return;
    }
    
    const videoId = extractYouTubeVideoId(currentVideoUrl);
    let downloadUrl = '';
    
    switch(service) {
        case 'ytmp3':
            // YTBmp3 - paste URL manually
            downloadUrl = `https://ytbmp3.com/`;
            showNotification('Opening YTBmp3... Paste your YouTube URL there to download!', 'success');
            break;
        case 'y2mate':
            // YTMP3.nu
            downloadUrl = `https://ytmp3.nu/`;
            showNotification('Opening YTMP3.nu... Paste your YouTube URL there to download!', 'success');
            break;
        case 'loader':
            // Loader.to with direct URL
            downloadUrl = `https://loader.to/api/button/?url=${encodeURIComponent(currentVideoUrl)}`;
            showNotification('Opening Loader.to...', 'success');
            break;
        case 'savefrom':
            // SaveFrom.net with URL parameter
            downloadUrl = `https://en.savefrom.net/#url=${encodeURIComponent(currentVideoUrl)}`;
            showNotification('Opening SaveFrom.net...', 'success');
            break;
        case 'mp3juice':
            // MP3 Juice - search with video title or URL
            downloadUrl = `https://mp3juices.cc/`;
            showNotification('Opening MP3 Juice... Search for your song there!', 'success');
            break;
        case 'yt5s':
            // YTMP3s
            downloadUrl = `https://ytmp3s.nu/`;
            showNotification('Opening YTMP3s... Paste your YouTube URL there to download!', 'success');
            break;
        default:
            showNotification('Service not available', 'error');
            return;
    }
    
    // Open in new tab
    window.open(downloadUrl, '_blank');
    
    // Copy URL to clipboard for easy pasting
    if (navigator.clipboard) {
        navigator.clipboard.writeText(currentVideoUrl).then(() => {
            setTimeout(() => {
                showNotification('YouTube URL copied to clipboard! Paste it in the download site.', 'success');
            }, 1000);
        }).catch(() => {
            // Clipboard API failed, that's okay
        });
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + 1-7 for quick navigation
    if ((e.ctrlKey || e.metaKey) && e.key >= '1' && e.key <= '7') {
        e.preventDefault();
        const sections = ['home', 'spotify', 'youtube', 'saved-songs', 'offline-music', 'downloader', 'playlists'];
        showSection(sections[parseInt(e.key) - 1]);
    }
    
    // Space bar for play/pause (when not in input field)
    if (e.code === 'Space' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
        e.preventDefault();
        togglePlay();
    }
});

// Easter egg - Konami code
let konamiCode = [];
const konami = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];

document.addEventListener('keydown', function(e) {
    konamiCode.push(e.key);
    konamiCode = konamiCode.slice(-10);
    
    if (konamiCode.join(',') === konami.join(',')) {
        activatePartyMode();
    }
});

function activatePartyMode() {
    showNotification('🎉 Party Mode Activated! 🎉', 'success');
    document.body.style.animation = 'rainbow 2s infinite';
    
    const rainbowStyle = document.createElement('style');
    rainbowStyle.textContent = `
        @keyframes rainbow {
            0% { filter: hue-rotate(0deg); }
            100% { filter: hue-rotate(360deg); }
        }
    `;
    document.head.appendChild(rainbowStyle);
    
    setTimeout(() => {
        document.body.style.animation = '';
        rainbowStyle.remove();
    }, 10000);
}

// Saved Songs Management
function saveSongToHistory(url, type) {
    let savedSongs = JSON.parse(localStorage.getItem('tunelocal_saved_songs') || '[]');
    
    // Check if URL already exists
    const existingIndex = savedSongs.findIndex(song => song.url === url);
    
    if (existingIndex !== -1) {
        // Update timestamp and move to top
        savedSongs.splice(existingIndex, 1);
    }
    
    // Extract title from URL
    let title = extractTitleFromUrl(url, type);
    
    const savedSong = {
        id: Date.now(),
        url: url,
        type: type,
        title: title,
        dateAdded: new Date().toLocaleString()
    };
    
    // Add to beginning of array
    savedSongs.unshift(savedSong);
    
    // Keep only last 50 songs
    if (savedSongs.length > 50) {
        savedSongs = savedSongs.slice(0, 50);
    }
    
    localStorage.setItem('tunelocal_saved_songs', JSON.stringify(savedSongs));
    loadSavedSongs();
}

function extractTitleFromUrl(url, type) {
    if (type === 'spotify') {
        // Extract Spotify type and ID
        const match = url.match(/spotify\.com\/(playlist|album|track|artist)\/([a-zA-Z0-9]+)/);
        if (match) {
            const contentType = match[1].charAt(0).toUpperCase() + match[1].slice(1);
            return `Spotify ${contentType}`;
        }
    } else if (type === 'youtube') {
        // For YouTube, just indicate it's a video/playlist
        if (url.includes('list=')) {
            return 'YouTube Playlist';
        }
        return 'YouTube Video';
    }
    return `${type.charAt(0).toUpperCase() + type.slice(1)} Content`;
}

function loadSavedSongs(filter = 'all') {
    const savedSongs = JSON.parse(localStorage.getItem('tunelocal_saved_songs') || '[]');
    const container = document.getElementById('savedSongsGrid');
    
    let filteredSongs = savedSongs;
    if (filter !== 'all') {
        filteredSongs = savedSongs.filter(song => song.type === filter);
    }
    
    if (filteredSongs.length === 0) {
        container.innerHTML = `
            <div class="empty-saved-songs" style="grid-column: 1 / -1;">
                <i class="fas fa-music"></i>
                <h3>No Saved Songs Yet</h3>
                <p>Load songs from Spotify or YouTube and they'll automatically appear here!</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filteredSongs.map(song => `
        <div class="saved-song-card" data-type="${song.type}">
            <div class="saved-song-header">
                <div class="saved-song-info">
                    <div class="saved-song-type ${song.type}">
                        <i class="fab fa-${song.type}"></i>
                        <span>${song.type.charAt(0).toUpperCase() + song.type.slice(1)}</span>
                    </div>
                    <div class="saved-song-title">${song.title}</div>
                    <div class="saved-song-date">
                        <i class="fas fa-clock"></i> ${song.dateAdded}
                    </div>
                </div>
            </div>
            <div class="saved-song-url">${truncateUrl(song.url)}</div>
            <div class="saved-song-actions">
                <button class="btn btn-primary" onclick="playSavedSong('${song.url}', '${song.type}')" style="flex: 1; justify-content: center;">
                    <i class="fas fa-play"></i> Play
                </button>
                <button class="icon-btn delete" onclick="deleteSavedSong(${song.id})" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function truncateUrl(url) {
    if (url.length > 60) {
        return url.substring(0, 57) + '...';
    }
    return url;
}

function filterSavedSongs(filter) {
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.closest('.filter-btn').classList.add('active');
    
    loadSavedSongs(filter);
}

function playSavedSong(url, type) {
    if (type === 'spotify') {
        document.getElementById('spotifyUrl').value = url;
        showSection('spotify');
        
        // Load without saving again
        const embedUrl = convertToSpotifyEmbed(url);
        const playerDiv = document.getElementById('spotifyPlayer');
        playerDiv.innerHTML = `
            <iframe 
                style="border-radius:12px" 
                src="${embedUrl}" 
                width="100%" 
                height="400" 
                frameBorder="0" 
                allowfullscreen="" 
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
                loading="lazy">
            </iframe>
        `;
    } else if (type === 'youtube') {
        document.getElementById('youtubeUrl').value = url;
        showSection('youtube');
        
        // Load without saving again
        const embedUrl = convertToYouTubeEmbed(url);
        const playerDiv = document.getElementById('youtubePlayer');
        playerDiv.innerHTML = `
            <iframe 
                width="100%" 
                height="500" 
                src="${embedUrl}" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen
                style="border-radius: 16px;">
            </iframe>
        `;
    }
    
    showNotification('Playing saved song!', 'success');
}

function deleteSavedSong(id) {
    if (!confirm('Remove this song from saved songs?')) {
        return;
    }
    
    let savedSongs = JSON.parse(localStorage.getItem('tunelocal_saved_songs') || '[]');
    savedSongs = savedSongs.filter(song => song.id !== id);
    localStorage.setItem('tunelocal_saved_songs', JSON.stringify(savedSongs));
    
    loadSavedSongs();
    showNotification('Song removed from saved songs', 'success');
}

// ==================== Discover Music Section ====================

const musicCollections = [
    // Happy Music
    {
        id: 'happy-pop',
        title: 'Happy Pop Vibes',
        description: 'Upbeat pop songs to brighten your day and get you moving',
        category: 'happy',
        platform: 'spotify',
        icon: '😊',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DXdPec7aLTmlC'
    },
    {
        id: 'happy-indie',
        title: 'Feel Good Indie',
        description: 'Indie tracks that will put a smile on your face',
        category: 'happy',
        platform: 'spotify',
        icon: '🌈',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX9sIqqvKsjG8'
    },
    {
        id: 'happy-mix',
        title: 'Happy Hits',
        description: 'The most joyful and energizing songs from all genres',
        category: 'happy',
        platform: 'youtube',
        icon: '🎉',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI'
    },
    
    // Chill/Relaxing Music
    {
        id: 'chill-vibes',
        title: 'Chill Vibes',
        description: 'Smooth and relaxing tracks for unwinding',
        category: 'chill',
        platform: 'spotify',
        icon: '🌙',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX4WYpdgoIcn6'
    },
    {
        id: 'peaceful-piano',
        title: 'Peaceful Piano',
        description: 'Beautiful piano melodies for relaxation and focus',
        category: 'chill',
        platform: 'spotify',
        icon: '🎹',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX4sWSpwq3LiO'
    },
    {
        id: 'chill-acoustic',
        title: 'Acoustic Chill',
        description: 'Gentle acoustic songs to calm your mind',
        category: 'chill',
        platform: 'youtube',
        icon: '🎸',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLMSAf2qXzZzYe2N-pxVnrEL9FWbQ7UVFV'
    },
    
    // Sad/Emotional Music
    {
        id: 'sad-songs',
        title: 'Sad Songs',
        description: 'Emotional ballads for when you need to feel your feelings',
        category: 'sad',
        platform: 'spotify',
        icon: '💔',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX3YSRoSdA634'
    },
    {
        id: 'melancholic',
        title: 'Melancholic Moods',
        description: 'Beautiful melancholic tracks for introspective moments',
        category: 'sad',
        platform: 'spotify',
        icon: '🌧️',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX7qK8ma5wgG1'
    },
    {
        id: 'emotional-piano',
        title: 'Emotional Piano',
        description: 'Heart-touching piano compositions',
        category: 'sad',
        platform: 'youtube',
        icon: '😢',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLw-0-FN28qyADdF8dJumKb2Y3VnhVxqPR'
    },
    
    // Energetic/Workout Music
    {
        id: 'workout-motivation',
        title: 'Workout Motivation',
        description: 'High-energy tracks to power through your workout',
        category: 'energetic',
        platform: 'spotify',
        icon: '💪',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX76Wlfdnj7AP'
    },
    {
        id: 'beast-mode',
        title: 'Beast Mode',
        description: 'Aggressive beats to unleash your inner beast',
        category: 'energetic',
        platform: 'spotify',
        icon: '🔥',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX70RN3TfWWJh'
    },
    {
        id: 'edm-workout',
        title: 'EDM Workout',
        description: 'Electronic dance music for maximum energy',
        category: 'energetic',
        platform: 'youtube',
        icon: '⚡',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLYUn4YaogdahwfSZFMG5s3wSNhGu1ohls'
    },
    
    // Anime Music
    {
        id: 'anime-openings',
        title: 'Anime Openings',
        description: 'Epic anime opening themes from popular series',
        category: 'anime',
        platform: 'youtube',
        icon: '🎌',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLwazKLaN7rLhV89fwraGUmsk5N4bH28Rx'
    },
    {
        id: 'anime-ost',
        title: 'Anime Soundtracks',
        description: 'Beautiful soundtracks from beloved anime series',
        category: 'anime',
        platform: 'youtube',
        icon: '🎬',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLhzubg2dJf9ipRK1-ZBRcQy-_RbmB5FGA'
    },
    {
        id: 'anime-emotional',
        title: 'Emotional Anime OST',
        description: 'Heart-touching anime music for the feels',
        category: 'anime',
        platform: 'youtube',
        icon: '😭',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLRmVsLlLaU7jqIvQTEHPEZCBEH_WOKlI7'
    },
    
    // Phonk Music
    {
        id: 'phonk-drift',
        title: 'Phonk Drift',
        description: 'Aggressive phonk beats for night drives',
        category: 'phonk',
        platform: 'youtube',
        icon: '🚗',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLHmTsVREU3Ar1AJWkimkl6Pux3R5PB-QJ'
    },
    {
        id: 'brazilian-phonk',
        title: 'Brazilian Phonk',
        description: 'Dark Brazilian phonk for intense vibes',
        category: 'phonk',
        platform: 'youtube',
        icon: '🌙',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLYUn4Yaogdagd7r-TuN67x1MgE8z4oLy6'
    },
    {
        id: 'memphis-phonk',
        title: 'Memphis Phonk',
        description: 'Classic Memphis-style phonk tracks',
        category: 'phonk',
        platform: 'youtube',
        icon: '🔊',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLzCxunOM5WFLXwBk1ZNKXuSo5tNGcSDC9'
    },
    
    // Lo-Fi Music
    {
        id: 'lofi-study',
        title: 'Lo-Fi Study Beats',
        description: 'Chill beats to study and relax to',
        category: 'lofi',
        platform: 'youtube',
        icon: '📚',
        embedUrl: 'https://www.youtube.com/embed/jfKfPfyJRdk'
    },
    {
        id: 'lofi-sleep',
        title: 'Lo-Fi Sleep',
        description: 'Gentle lo-fi beats for peaceful sleep',
        category: 'lofi',
        platform: 'youtube',
        icon: '😴',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLOzDu-MXXLliO9fBNZOQTBDddoA3FzZUo'
    },
    {
        id: 'lofi-jazz',
        title: 'Lo-Fi Jazz Hip Hop',
        description: 'Smooth jazz-influenced lo-fi hip hop beats',
        category: 'lofi',
        platform: 'spotify',
        icon: '🎷',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DWWQRwui0ExPn'
    },
    
    // Rock Music
    {
        id: 'rock-classics',
        title: 'Rock Classics',
        description: 'Legendary rock anthems from the greatest bands',
        category: 'rock',
        platform: 'spotify',
        icon: '🎸',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DWXRqgorJj26U'
    },
    {
        id: 'modern-rock',
        title: 'Modern Rock',
        description: 'Contemporary rock hits and alternative tracks',
        category: 'rock',
        platform: 'spotify',
        icon: '🤘',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DXcF6B6QPhFDv'
    },
    {
        id: 'rock-workout',
        title: 'Rock Workout',
        description: 'High-energy rock for intense workouts',
        category: 'rock',
        platform: 'youtube',
        icon: '💥',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLw-0-FN28qyCx-1HdMJVfLPEEOa2qGqXJ'
    },
    
    // Electronic Music
    {
        id: 'edm-festival',
        title: 'EDM Festival Hits',
        description: 'Biggest EDM bangers from festivals worldwide',
        category: 'electronic',
        platform: 'spotify',
        icon: '🎧',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX4JAvHpjipBk'
    },
    {
        id: 'house-music',
        title: 'House Music',
        description: 'Deep house and progressive house grooves',
        category: 'electronic',
        platform: 'spotify',
        icon: '🏠',
        embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX8tZsk68tuDw'
    },
    {
        id: 'dubstep',
        title: 'Dubstep Drops',
        description: 'Heavy dubstep with massive bass drops',
        category: 'electronic',
        platform: 'youtube',
        icon: '🔊',
        embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLYUn4YaogdaiS5NZ0FPBQqA3pVKhXu9PD'
    }
];

let currentDiscoverCategory = 'all';

function initializeDiscover() {
    renderDiscoverGrid();
    setupCategoryFilters();
}

function setupCategoryFilters() {
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentDiscoverCategory = btn.dataset.category;
            renderDiscoverGrid();
        });
    });
}

function renderDiscoverGrid() {
    const grid = document.getElementById('discoverGrid');
    if (!grid) return;
    
    let filteredCollections = musicCollections;
    if (currentDiscoverCategory !== 'all') {
        filteredCollections = musicCollections.filter(c => c.category === currentDiscoverCategory);
    }
    
    grid.innerHTML = filteredCollections.map(collection => `
        <div class="discover-card" onclick="playDiscoverMusic('${collection.id}')">
            <div class="discover-card-header">
                <div class="discover-card-icon">${collection.icon}</div>
                <div class="discover-card-title">
                    <h3>${collection.title}</h3>
                    <span class="discover-card-category">${collection.category}</span>
                </div>
            </div>
            <p class="discover-card-description">${collection.description}</p>
            <div class="discover-card-footer">
                <div class="discover-card-platform">
                    <i class="fab fa-${collection.platform}"></i>
                    <span>${collection.platform === 'spotify' ? 'Spotify' : 'YouTube'}</span>
                </div>
                <div class="discover-card-play">
                    <i class="fas fa-play"></i>
                </div>
            </div>
        </div>
    `).join('');
}

function playDiscoverMusic(collectionId) {
    const collection = musicCollections.find(c => c.id === collectionId);
    if (!collection) return;
    
    const modal = document.getElementById('discoverPlayerModal');
    const title = document.getElementById('discoverModalTitle');
    const container = document.getElementById('discoverPlayerContainer');
    
    title.innerHTML = `<i class="fas fa-music"></i> ${collection.title}`;
    
    container.innerHTML = `
        <iframe 
            src="${collection.embedUrl}" 
            width="100%" 
            height="500" 
            frameborder="0" 
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
            loading="lazy"
            style="border-radius: 12px;">
        </iframe>
    `;
    
    modal.style.display = 'flex';
    showNotification(`Now playing: ${collection.title}`, 'success');
}

function closeDiscoverPlayer() {
    const modal = document.getElementById('discoverPlayerModal');
    const container = document.getElementById('discoverPlayerContainer');
    modal.style.display = 'none';
    container.innerHTML = ''; // Stop playback
}

// Close discover modal with ESC key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const modal = document.getElementById('discoverPlayerModal');
        if (modal && modal.style.display === 'flex') {
            closeDiscoverPlayer();
        }
    }
});

// Console welcome message
console.log('%c🎵 Welcome to TuneLocal! 🎵', 'color: #1db954; font-size: 20px; font-weight: bold;');
console.log('%cEnjoy your music streaming experience!', 'color: #667eea; font-size: 14px;');
console.log('%cKeyboard shortcuts: Ctrl/Cmd + 1-7 to navigate | Space to play/pause', 'color: #b3b3b3; font-size: 12px;');
