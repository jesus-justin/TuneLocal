TuneLocal Application Package

How to run:
1. Install XAMPP at C:\xampp
2. Extract this ZIP
3. Double-click TuneLocalApp.exe

If .exe is blocked, use TuneLocalApp.bat.
