@echo off
setlocal

set "APP_NAME=TuneLocal"
set "PKG_DIR=%~dp0..\TuneLocal"
set "XAMPP_DIR=C:\xampp"
set "HTDOCS_DIR=%XAMPP_DIR%\htdocs"
set "TARGET_DIR=%HTDOCS_DIR%\%APP_NAME%"
set "LOCAL_URL=http://localhost/%APP_NAME%/"

echo ==========================================
echo   TuneLocal Launcher
echo ==========================================

if not exist "%XAMPP_DIR%\apache_start.bat" (
  echo ERROR: XAMPP not found at %XAMPP_DIR%
  echo Install XAMPP first: https://www.apachefriends.org/
  pause
  exit /b 1
)

if not exist "%PKG_DIR%\index.php" (
  echo ERROR: App files not found in package path:
  echo %PKG_DIR%
  pause
  exit /b 1
)

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo Copying TuneLocal files to %TARGET_DIR% ...
xcopy "%PKG_DIR%\*" "%TARGET_DIR%\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo ERROR: Failed to copy app files into htdocs.
  pause
  exit /b 1
)

start "" "%XAMPP_DIR%\apache_start.bat"
start "" "%XAMPP_DIR%\mysql_start.bat"

echo Starting app in browser...
timeout /t 4 /nobreak >nul
start "" "%LOCAL_URL%"

echo.
echo TuneLocal is running at: %LOCAL_URL%
echo If login/database fails, import:
echo %TARGET_DIR%\database\tunelocal.sql
echo.
pause
